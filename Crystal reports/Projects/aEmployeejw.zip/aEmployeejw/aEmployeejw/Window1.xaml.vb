﻿Class Window1

    Public Sub New()

        ' This call is required by the designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        ReportViewer.Owner = Me

    End Sub
End Class
